package learning;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

import static java.lang.System.exit;
import static java.lang.System.out;

public class test_point {
    public static void ajouterWorker(DB_again test) {
        Scanner sc = new Scanner(System.in);
        Worker worker = new Worker(sc.nextInt(),sc.next(),sc.next(),sc.nextInt(),sc.nextInt());
        test.ajoutWorker(worker);
    }
    public static void afficherWorkers(DB_again test) {
        try {
            ArrayList<Worker> workers = test.selectAll();
            for (Worker worker : workers) {
                out.println(worker.toString());
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    public static void afficherWorkerId(int id, DB_again test) {
        ResultSet rs = test.executeSelectAll("select * from worker where idworker = " + id);
        try {
            rs.next();
            out.println(new Worker(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getDouble(4),rs.getInt(5)));
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        DB_again test = new DB_again();
        int choix = 0;
        boolean running = true;
        while (running){
            System.out.println("choose option:\n(1) select all\n(2) select by id\n(3) insert a new worker \n(6)exit");
            choix = sc.nextInt();
            switch(choix){
                case 1:afficherWorkers(test);break;
                case 2:int id = sc.nextInt();
                    afficherWorkerId(id,test);
                    ;break;
                case 3:ajouterWorker(test);break;
                case 6: out.println("thank you so much for using this app bye bye");
                    running = false;break;
            }
        }
    }
}
