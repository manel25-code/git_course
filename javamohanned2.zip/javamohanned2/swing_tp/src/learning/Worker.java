package learning;

public record Worker(int id, String nom,String prenom,double sal, int age) {
}
