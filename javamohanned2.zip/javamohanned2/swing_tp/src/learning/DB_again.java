package learning;

import java.sql.*;
import java.util.ArrayList;

public class DB_again {
    Connection conn;
    public DB_again() {
        try {
            conn = DriverManager.getConnection(
                    config.url,
                    config.userName,
                    config.password
            );
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public  ResultSet executeSelectAll(String sql) {
        try {
            Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
            return stmt.executeQuery(sql);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public int ajoutWorker(Worker worker) {
        String Sql = "insert into worker values(?,?,?,?,?)";
        try {
            PreparedStatement ps = conn.prepareStatement(Sql);
            ps.setInt(1,worker.id());
            ps.setString(2,worker.nom());
            ps.setString(3,worker.prenom());
            ps.setDouble(4,worker.sal());
            ps.setInt(5,worker.age());
            return ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public ArrayList<Worker> selectAll() throws SQLException {
        String Sql = "select * from worker";
        ResultSet rs = executeSelectAll(Sql);
        ArrayList<Worker> workers = new ArrayList<>();
        while(rs.next()){
            workers.add(new Worker(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getDouble(4),rs.getInt(5)));
        }
        return workers;
    }
}