package learning;

public record config() {
    public static final String nomDriver = "com.mysql.cj.jdbc.Driver";
    final static String url = "jdbc:mysql://localhost:3306/swingDatabase";
    final static String userName = "root";
    final static String password = "root";
}
