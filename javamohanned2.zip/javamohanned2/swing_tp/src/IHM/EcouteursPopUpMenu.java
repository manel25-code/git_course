package IHM;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class EcouteursPopUpMenu implements ActionListener {
    GestionProfil gp;

    public EcouteursPopUpMenu(GestionProfil gp) {
        this.gp = gp;
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==gp.item2){
            gp.list_Panel.clear();
            gp.jtp.removeAll();
            Data.data.clear();
            gp.model.removeAllElements();
        }
         if(e.getSource()==gp.item1) {
             int selectedIndex = gp.jl.getSelectedIndex(); // Stocker l'index avant de supprimer

             if (selectedIndex != -1) { // Vérifier qu'un élément est bien sélectionné
                 Data.data.remove(selectedIndex); // Retirer des données
                 gp.model.remove(selectedIndex);  // Retirer de la liste graphique
                 gp.jtp.removeTabAt(selectedIndex); // Retirer de JTabbedPane
             } else {
                 JOptionPane.showMessageDialog(null, "Veuillez sélectionner un élément à supprimer.");
             }
             //Data.data.remove(gp.jl.getSelectedIndex());//retirer du donnees
             //gp.model.remove(gp.jl.getSelectedIndex());//retirer mel interface
             //gp.jtp.removeTabAt(gp.jl.getSelectedIndex());//nkamlou heshy
             //bouton enregistrer verifier si le pseudo mawjoud wl lee
             //modifier fel liste heki m3mlou ay haja :
             //nkamlou l interface du tp4
         }


         if(e.getSource()==gp.item) {
             int selectedIndex = gp.jl.getSelectedIndex(); // Récupérer l'index sélectionné

             if (selectedIndex != -1) { // Vérifier qu'un élément est bien sélectionné
                 String nouveauPseudo = JOptionPane.showInputDialog(null, "Entrez le nouveau pseudo :");

                 if (nouveauPseudo != null && !nouveauPseudo.trim().isEmpty()) { // Vérifier que le champ n'est pas vide
                     nouveauPseudo = nouveauPseudo.trim();

                     // Vérifier si le pseudo existe déjà
                     boolean pseudoExiste = false;
                     for (Profil profil : Data.data) {
                         if (profil.getPseudo().equalsIgnoreCase(nouveauPseudo)) {
                             pseudoExiste = true;
                             break;
                         }
                     }

                     if (pseudoExiste) {
                         JOptionPane.showMessageDialog(null, "Erreur : Ce pseudo existe déjà. Veuillez en choisir un autre.");
                     } else {
                         // Modifier le pseudo dans les données
                         Data.data.get(selectedIndex).setPseudo(nouveauPseudo);

                         // Modifier dans l'interface graphique (JList)
                         gp.model.setElementAt(nouveauPseudo, selectedIndex);
                         gp.jtp.setTitleAt(selectedIndex, nouveauPseudo);

                         JOptionPane.showMessageDialog(null, "Pseudo modifié avec succès !");
                     }
                 } else {
                     JOptionPane.showMessageDialog(null, "Erreur : Le pseudo ne peut pas être vide.");
                 }
             } else {
                 JOptionPane.showMessageDialog(null, "Veuillez sélectionner un pseudo à modifier.");
             }
         }
         }

    }

