package IHM;

//public class Test {
  //  public static void main(String[] args) {
        //initialisation de la fenetre
// JFrame f= new JFrame();
// f.setTitle("CV DE ELA");
// f.setSize(800,600);
// f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
// f.setLayout(new FlowLayout()); //bejnab b3a4hom
// JButton btnvalide = new JButton("valider") ;
// f.add(btnvalide);
// JButton btnQte = new JButton("Quitter");
// f.add(btnQte);
// f.setVisible(true);

        //CurriculumForm cv=new CurriculumForm();
       // cv.setVisible(true);
       // Bureau bureau = new Bureau();
        //bureau.setVisible(true);}


    //}


