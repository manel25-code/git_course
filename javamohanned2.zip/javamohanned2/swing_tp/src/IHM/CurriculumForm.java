package IHM;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class CurriculumForm extends JFrame {

    JLabel lb_titre;

    public CurriculumForm() {

        this.setTitle("CV ");
        this.setSize(800, 800);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLayout(new BorderLayout());

        // Titre
        lb_titre = new JLabel("Curriculum vitae", SwingConstants.CENTER);
        lb_titre.setForeground(Color.white);
        lb_titre.setFont(new Font(Font.SERIF, Font.BOLD, 32));
        lb_titre.setOpaque(true);
        lb_titre.setBackground(Color.green);
        this.add(lb_titre, BorderLayout.NORTH);  // Titre en haut

        // Panel central pour les champs de formulaire
        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new GridLayout(0, 2, 10, 10));
        this.add(centerPanel, BorderLayout.CENTER);

        // Nom
        JLabel lb_nom = new JLabel("Nom");
        JTextField tf_nom = new JTextField(40);
        centerPanel.add(lb_nom);
        centerPanel.add(tf_nom);

        // Prénom
        JLabel lb_prenom = new JLabel("Prenom");
        JTextField tf_prenom = new JTextField(40);
        centerPanel.add(lb_prenom);
        centerPanel.add(tf_prenom);

        // Mot de passe
        JLabel lblPassword = new JLabel("Password :");
        JPasswordField txtPassword = new JPasswordField(40);
        centerPanel.add(lblPassword);
        centerPanel.add(txtPassword);

        // Langue
        JLabel lblLangue = new JLabel("Langue :");
        String[] langues = { "Arabe", "Français", "Anglais", "Italien", "Espagnol", "Allemand" };
        JList<String> listLangue = new JList<>(langues);
        JScrollPane scrollLangue = new JScrollPane(listLangue);
        centerPanel.add(lblLangue);
        centerPanel.add(scrollLangue);

        // Sexe
        JLabel lblSexe = new JLabel("Sexe :");
        JRadioButton rbMale = new JRadioButton("Male");
        JRadioButton rbFemelle = new JRadioButton("Femelle");
        ButtonGroup sexeGroup = new ButtonGroup();
        sexeGroup.add(rbMale);
        sexeGroup.add(rbFemelle);
        JPanel sexPanel = new JPanel();
        sexPanel.add(rbMale);
        sexPanel.add(rbFemelle);
        centerPanel.add(lblSexe);
        centerPanel.add(sexPanel);

        // Date de naissance
        JLabel lblDateNaissance = new JLabel("Date de naissance :");
        String[] jours = { "01", "02", "03", "04", "05" };
        String[] mois = { "01", "02", "03", "04", "05" };
        String[] annees = { "2012", "2011", "2010" };
        JComboBox<String> cbJour = new JComboBox<>(jours);
        JComboBox<String> cbMois = new JComboBox<>(mois);
        JComboBox<String> cbAnnee = new JComboBox<>(annees);
        JPanel datePanel = new JPanel();
        datePanel.add(cbJour);
        datePanel.add(cbMois);
        datePanel.add(cbAnnee);
        centerPanel.add(lblDateNaissance);
        centerPanel.add(datePanel);

        // Ville
        JLabel lblVille = new JLabel("Ville :");
        String[] villes = { "Ariana", "Medenine", "Sfax", "Tunis", "Sidi Bouzid", "Bizerte", "Gabès", "Nabeul", "Monastir" };
        JComboBox<String> cbVille = new JComboBox<>(villes);
        centerPanel.add(lblVille);
        centerPanel.add(cbVille);

        // Adresse
        JLabel lblAdresse = new JLabel("Adresse :");
        JTextField txtAdresse = new JTextField(40);
        JScrollPane scrollPane = new JScrollPane(txtAdresse);
        centerPanel.add(lblAdresse);
        centerPanel.add(scrollPane);

        // Loisirs
        JLabel lblLoisir = new JLabel("Loisir :");
        JCheckBox chkJava = new JCheckBox("Java");
        JCheckBox chkFoot = new JCheckBox("Foot");
        JCheckBox chkMusic = new JCheckBox("Music");
        JCheckBox chkCuisine = new JCheckBox("Cuisine");
        JCheckBox chkVoyage = new JCheckBox("Voyage");
        JPanel loisirsPanel = new JPanel();
        loisirsPanel.add(chkJava);
        loisirsPanel.add(chkFoot);
        loisirsPanel.add(chkMusic);
        loisirsPanel.add(chkCuisine);
        loisirsPanel.add(chkVoyage);
        centerPanel.add(lblLoisir);
        centerPanel.add(loisirsPanel);


        JLabel lbPhoto = new JLabel("Photo :");
        JLabel lblImage = new JLabel(); // Le JLabel qui affichera l'image
        lblImage.setPreferredSize(new Dimension(200, 200)); // Taille par défaut du JLabel pour l'image
        centerPanel.add(lbPhoto);
        centerPanel.add(lblImage);
        JButton btnAjouterPhoto = new JButton("Ajouter Photo");
        centerPanel.add(btnAjouterPhoto);

        btnAjouterPhoto.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser fileChooser = new JFileChooser();
                fileChooser.setDialogTitle("Choisir une photo");
                fileChooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("Images", "jpg", "png"));

                int result = fileChooser.showOpenDialog(null);
                if (result == JFileChooser.APPROVE_OPTION) {
                    File file = fileChooser.getSelectedFile();
                    String filePath = file.getAbsolutePath();
                    ImageIcon imageIcon = new ImageIcon(filePath);
                    lblImage.setIcon(imageIcon);  // Afficher l'image
                }
            }
        });


        JPanel bottomPanel = new JPanel();
        bottomPanel.setLayout(new FlowLayout(FlowLayout.CENTER));
        this.add(bottomPanel, BorderLayout.SOUTH);

        JButton btnValide = new JButton("Valider");
        JButton btnQte = new JButton("Quitter");
        bottomPanel.add(btnValide);
        bottomPanel.add(btnQte);

        // Evénements
        btnQte.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

        btnValide.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Code pour générer le fichier HTML
                File f = new File("cv.html");
                try {
                    FileWriter fw = new FileWriter(f, false);
                    String nom = tf_nom.getText();
                    String prenom = tf_prenom.getText();
                    String langue=listLangue.getSelectedValue();
                    String sexe;
                    if (rbMale.isSelected()) {
                        sexe = "Homme";
                    } else {
                        sexe = "Femme";
                    }
                    String dateNaissance=cbJour.getSelectedItem() + "/" + cbMois.getSelectedItem() + "/" + cbAnnee.getSelectedItem();
                    String ville = (String) cbVille.getSelectedItem();
                    String adresse=txtAdresse.getText();
                    String loisirs = "";
                    if (chkJava.isSelected()) loisirs += "Java ";
                    if (chkFoot.isSelected()) loisirs += "Foot ";
                    if (chkMusic.isSelected()) loisirs += "Musique ";
                    if (chkCuisine.isSelected()) loisirs += "Cuisine ";

                    fw.write("<html>" +
                            "<head><title>Curriculum Vitae</title></head>" +
                            "<body>" +
                            "<h1>" + nom + " " + prenom + "</h1>" +
                            "<p><strong>Nom:</strong> " + nom + "</p>" +
                            "<p><strong>Prénom:</strong> " + prenom + "</p>" +
                            "<p><strong>Langue:</strong> " + langue + "</p>" +
                            "<p><strong>Sexe:</strong> " + sexe + "</p>" +
                            "<p><strong>Date de naissance:</strong> " + dateNaissance + "</p>" +
                            "<p><strong>Ville:</strong> " + ville + "</p>" +
                            "<p><strong>Adresse:</strong> " + adresse + "</p>" +
                            "<p><strong>Loisirs:</strong> " + loisirs + "</p>" +
                            (lblImage.getIcon() != null ?
                                    "<p><strong>Photo:</strong><br><img src=\"" + ((ImageIcon) lblImage.getIcon()).toString() + "\" alt=\"Photo\" width=\"200\" height=\"200\"></p>"
                                    : "") +
                            "</body>" +
                            "</html>");
                    fw.close();
                    Desktop.getDesktop().open(f);
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });}}






