package IHM;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class PanelForm extends JPanel {
    GestionProfil gp;
    JButton button;
    JLabel label;
    Profil p;
    JPanel optionsPanel,options2Panel;
    JComboBox<String> difficultyComboBox;
    Border border,border1;
    public PanelForm(Profil p) {
        this.gp = new GestionProfil();
        this.p = p;
        this.setBackground(Color.cyan);
        this.setLayout(new BorderLayout());
        label = new JLabel("Bienvenue" + "" + p.getNom() + " " + p.getPrenom());
        label.setFont(new Font("Serif", Font.BOLD, 20));
        this.add(label, BorderLayout.NORTH);
        String[] difficulties = {"Débutant", "Intermédiaire", "Avancé"}; // Options de la difficulté
        difficultyComboBox = new JComboBox<>(difficulties); // Créer la combo box
        difficultyComboBox.setPreferredSize(new Dimension(150, 30)); // Taille de la liste déroulante

        // Ajouter la liste déroulante au centre du panel
        JPanel difficultyPanel = new JPanel();
        difficultyPanel.setLayout(new FlowLayout());
        difficultyPanel.add(difficultyComboBox);
        border = new LineBorder(Color.BLACK, 2);
        difficultyPanel.setBorder(BorderFactory.createTitledBorder(border, "Difficulté"));

        optionsPanel = new JPanel();
        optionsPanel.setLayout(new FlowLayout(FlowLayout.LEFT)); // Disposition horizontale
        optionsPanel.setBorder(BorderFactory.createTitledBorder("Niveau"));
        options2Panel = new JPanel();
        options2Panel.setLayout(new FlowLayout(FlowLayout.LEFT)); // Disposition horizontale
        options2Panel.setBorder(BorderFactory.createTitledBorder("Option 2"));


        // Ajouter des cases à cocher pour "Option 2"
        JCheckBox emitCheckBox = new JCheckBox("Émettre");
        JCheckBox showScoreCheckBox = new JCheckBox("Afficher score");
        JCheckBox fullScreenCheckBox = new JCheckBox("Plein écran");
        JCheckBox shadowCheckBox = new JCheckBox("Ombre");

        // Ajouter les cases à cocher au panel Option 2
        options2Panel.add(emitCheckBox);
        options2Panel.add(showScoreCheckBox);
        options2Panel.add(fullScreenCheckBox);
        options2Panel.add(shadowCheckBox);

        // Ajouter les panels dans le layout principal
        this.add(difficultyPanel, BorderLayout.CENTER);
        this.add(options2Panel, BorderLayout.WEST);
        this.add(optionsPanel, BorderLayout.EAST);  // Les options à droite

        // Ajouter un écouteur pour la liste déroulante
        difficultyComboBox.addActionListener(e -> updateOptionsBasedOnDifficulty());

        // Initialiser les options en fonction de la difficulté par défaut
        updateOptionsBasedOnDifficulty();

        JPanel centerContainer = new JPanel(new GridLayout(3, 1, 10, 10)); // 3 lignes, 1 colonne
        centerContainer.add(difficultyPanel);
        centerContainer.add(optionsPanel);
        centerContainer.add(options2Panel);

        // Ajouter ce conteneur au centre
        this.add(centerContainer, BorderLayout.CENTER);
        // Ajouter le panel avec bordure dans le panel principal
        //this.add(difficultyPanel, BorderLayout.CENTER);
        // this.add(difficultyPanel, BorderLayout.CENTER);
        button = new JButton("Valider");
        this.add(button, BorderLayout.SOUTH);
        this.setVisible(true);
        button.addActionListener(e -> generateAndOpenHTML());
    }
            private void generateAndOpenHTML() {
                String fileName = "profil.html";
                try (PrintWriter writer = new PrintWriter(new FileWriter(fileName))) {
                    writer.println("<html>");
                    writer.println("<head>");
                    writer.println("<title>Profil Utilisateur</title>");
                    writer.println("<style>");
                    writer.println("body { font-family: Arial, sans-serif; margin: 20px; padding: 20px; }");
                    writer.println("h1, h2 { color: #333; }");
                    writer.println(".container { border: 2px solid #ccc; padding: 10px; margin-bottom: 20px; }");
                    writer.println("</style>");
                    writer.println("</head>");
                    writer.println("<body>");

                    // Section Informations personnelles
                    writer.println("<div class='container'>");
                    writer.println("<h1>Informations personnelles</h1>");
                    writer.println("<p><strong>Nom :</strong> " + p.getNom() + "</p>");
                    writer.println("<p><strong>Prénom :</strong> " + p.getPrenom() + "</p>");
                    writer.println("<p><strong>Pseudo :</strong> " + p.getPseudo() + "</p>");
                    writer.println("</div>");

                    // Section Configuration
                    writer.println("<div class='container'>");
                    writer.println("<h2>Configuration</h2>");
                    writer.println("<p><strong>Difficulté :</strong> " + difficultyComboBox.getSelectedItem() + "</p>");

                    writer.println("<h3>Catégories</h3>");
                    writer.println("<ul>");
                    for (Component comp : optionsPanel.getComponents()) {
                        if (comp instanceof JCheckBox) {
                            JCheckBox checkBox = (JCheckBox) comp;
                            if (checkBox.isSelected()) {
                                writer.println("<li>" + checkBox.getText() + "</li>");
                            }
                        }
                    }
                    writer.println("</ul>");
                    writer.println("</div>");

                    // Section Options
                    writer.println("<div class='container'>");
                    writer.println("<h2>Options :</h2>");
                    writer.println("<ul>");
                    for (Component comp : options2Panel.getComponents()) {
                        if (comp instanceof JCheckBox) {
                            JCheckBox checkBox = (JCheckBox) comp;
                            writer.println("<li>" + checkBox.getText() + " : " + (checkBox.isSelected() ? "true" : "false") + "</li>");
                        }
                    }
                    writer.println("</ul>");
                    writer.println("</div>");

                    writer.println("</body></html>");
                } catch (IOException ex) {
                    ex.printStackTrace();
                }

                try {
                    File file = new File(fileName);
                    Desktop.getDesktop().browse(file.toURI());
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }

    private void updateOptionsBasedOnDifficulty() {
        optionsPanel.removeAll();

        // Récupérer le niveau de difficulté sélectionné
        String selectedDifficulty = (String) difficultyComboBox.getSelectedItem();

        // Créer un tableau des cases à cocher en fonction de la difficulté
        JCheckBox[] newCheckBoxes = new JCheckBox[0];

        switch (selectedDifficulty) {
            case "Débutant":
                newCheckBoxes = new JCheckBox[]{
                        new JCheckBox("1"),
                        new JCheckBox("2")
                };
                break;
            case "Intermédiaire":
                newCheckBoxes = new JCheckBox[]{
                        new JCheckBox(" 3"),
                        new JCheckBox("4")
                };
                break;
            case "Avancé":
                newCheckBoxes = new JCheckBox[]{
                        new JCheckBox("5"),
                        new JCheckBox("6"),
                        new JCheckBox("7")
                };
                break;
        }

        // Ajouter les nouvelles cases à cocher au panel
        for (JCheckBox checkBox : newCheckBoxes) {
            optionsPanel.add(checkBox);
        }

        // Revalider la mise en page
        optionsPanel.revalidate();
        optionsPanel.repaint();

    }}

