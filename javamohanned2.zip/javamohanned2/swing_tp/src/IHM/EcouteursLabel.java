package IHM;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class EcouteursLabel implements MouseListener {

    GestionProfil jp;
    public EcouteursLabel(GestionProfil jp) {
      this.jp = jp;
    }

    @Override
    public void mouseClicked(MouseEvent e) {

    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {
        if (e.getSource()==jp.lb_nom){
            jp.lb_nom.setForeground(Color.GREEN);

        }
        if (e.getSource()==jp.lb_prenom){
            jp.lb_prenom.setForeground(Color.red);
        }
        if (e.getSource()==jp.lb_pseudo){
            jp.lb_pseudo.setForeground(Color.cyan);

        }


    }

    @Override
    public void mouseExited(MouseEvent e) {
        if (e.getSource()==jp.lb_nom){
            jp.lb_nom.setForeground(Color.BLACK);

        }
        if (e.getSource()==jp.lb_prenom){
            jp.lb_prenom.setForeground(Color.BLACK);
        }
        if (e.getSource()==jp.lb_pseudo){
            jp.lb_pseudo.setForeground(Color.BLACK);

        }

    }
}
//ki badlt l couleur lel nom lezm yarj3ou kima kenou
//LORSQUE N7OT L CURSEUR 3al l une des text field lw lablel help affiche un message
//lorsque zone de saisie field(3al kol) gagne le focus elle devient vide y3ni l placeholder yetna7a et lorque lle perdre le focus et l utilisateur n a rien saisie tarj3 lvaleur par defaut