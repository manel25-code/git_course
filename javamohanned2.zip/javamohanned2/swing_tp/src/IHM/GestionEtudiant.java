package IHM;

import DB.EtudiantManager;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;


public class GestionEtudiant extends JFrame {
    JPanel panel;
    JLabel cin,nom, prenom, moyenne;
    JTextField jcin, jnom, jprenom,jmoyenne;
    JButton enregistrer;
    JTable jt;
    MyTableModel model;
    JPopupMenu popupMenu;
    GestionEtudiant() {
        this.setTitle("Gestion Etudiant");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(800, 900);
        this.setLayout(new FlowLayout());
        panel = new JPanel();
        panel.setLayout(new FlowLayout());

        // Initialisation des composants avant de les ajouter au panel
        cin = new JLabel("Cin");
        jcin= new JTextField(10);

        nom = new JLabel("Nom");
        jnom= new JTextField(10);

        prenom = new JLabel("Prenom");
        jprenom= new JTextField(10);

        moyenne = new JLabel("Moyenne");
        jmoyenne= new JTextField(10);
        enregistrer = new JButton("Enregistrer");
        panel.add(cin);
        panel.add(jcin);
        panel.add(nom);
        panel.add(jnom);
        panel.add(prenom);
        panel.add(jprenom);
        panel.add(moyenne);
        panel.add(jmoyenne);
        panel.add(enregistrer);
        this.add(panel,BorderLayout.NORTH);
        EtudiantManager manager=new EtudiantManager();
        String req="select * from Etudiant";
        ResultSet rs=manager.selectEtudiant(req);
        model=new MyTableModel(rs,manager);
        jt=new JTable();
        jt.setModel(model);
        this.add(new JScrollPane(jt),BorderLayout.CENTER);
        enregistrer.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int cin=Integer.parseInt(jcin.getText());
                String nom=jnom.getText();
                String prenom=jprenom.getText();
                double moyenne=Double.parseDouble(jmoyenne.getText());
                model.ajouterEtudiant(cin,nom,prenom,moyenne);
            }
        });
        popupMenu = new JPopupMenu();
        JMenuItem supprimerItem = new JMenuItem("Supprimer");
        popupMenu.add(supprimerItem);
        jt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                int row = jt.rowAtPoint(evt.getPoint());
                jt.setRowSelectionInterval(row, row); // sélectionner la ligne
                if (evt.isPopupTrigger()) {
                    popupMenu.show(jt, evt.getX(), evt.getY());
                }
            }

            public void mouseReleased(java.awt.event.MouseEvent evt) {
                if (evt.isPopupTrigger()) {
                    int row = jt.rowAtPoint(evt.getPoint());
                    jt.setRowSelectionInterval(row, row); // sélectionner la ligne
                    popupMenu.show(jt, evt.getX(), evt.getY());
                }
            }
        });




    }
    public static void main(String[] args) {

        GestionEtudiant gestionetudiant = new GestionEtudiant();
        gestionetudiant.setVisible(true);
    }}
//suppression kammalha