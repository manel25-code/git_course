package IHM;

import DB.EtudiantManager;

import javax.swing.*;
import javax.swing.table.AbstractTableModel;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;

public class MyTableModel extends AbstractTableModel {
    ResultSet  rs;
    EtudiantManager manager;
    ResultSetMetaData rsmd;
    ArrayList<Object[]> data=new ArrayList<Object[]>();//tableau d objet
    MyTableModel(ResultSet rs, EtudiantManager manager){
        this.rs=rs;
        this.manager=manager;
        try {
            rsmd=rs.getMetaData();
            while (rs.next()) {
            Object[] ligne=new Object[rsmd.getColumnCount()];
            //parcour
            for(int i=0;i< ligne.length;i++){
                ligne[i]=rs.getObject(i+1);
            }
            data.add(ligne);
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    @Override
    public int getRowCount() {
        //retourne le nb de ligne
        return data.size();
    }

    @Override
    public int getColumnCount() {
        //retourne le nb de colonnes
        try {
            return rsmd.getColumnCount();
        } catch (SQLException e) {
            return 0;
        }
    }

    @Override
    public String getColumnName(int column) {
        try {
            return rsmd.getColumnName(column+1);
        } catch (SQLException e) {
            return null;
        }
    }

    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        if(getColumnName(columnIndex).equalsIgnoreCase("moyenne"))
        return true;
        else
            return false;
    }

    @Override
    public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
        int cin=(int)data.get(rowIndex)[0];
        String nom=(String) data.get(rowIndex)[1];
        String prenom=(String) data.get(rowIndex)[2];
        double moyenne=Double.parseDouble(aValue+"");
        int a=manager.modifierEtudiant(cin,nom,prenom,moyenne);
        data.get(rowIndex)[columnIndex]=aValue;
    }
    public void ajouterEtudiant(int cin,String nom,String prenom,double moyenne){
        int a=manager.ajouterEtudiant(cin,nom,prenom,moyenne);
        if (a>0){
            data.add(new Object[]{cin, nom, prenom, moyenne});
            fireTableDataChanged();//refresh
        }
        else
            JOptionPane.showMessageDialog(null,"erreur d'insertion");

}
    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        //retourne les donnees des cellules
        return data.get(rowIndex)[columnIndex];
    }
    public boolean supprimerEtudiant(int cin) {
        int result = manager.supprimerEtudiant(cin); // méthode dans EtudiantManager
        return result > 0;
    }

    public void removeRow(int rowIndex) {
        data.remove(rowIndex);
        fireTableRowsDeleted(rowIndex, rowIndex);
    }




}
