package IHM;

import java.awt.*;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

public class EcouteurFocus implements FocusListener {
    GestionProfil ef;
    public EcouteurFocus(GestionProfil ef) {
        this.ef = ef;
    }

    @Override
    public void focusGained(FocusEvent e) {
        if (e.getSource()==ef.tf_nom){
            ef.tf_nom.setText("");
            ef.lb_help.setText("help:saisir votre nom");
        }
        if (e.getSource()==ef.tf_prenom){
            ef.tf_prenom.setText("");
            ef.lb_help.setText("help:saisir votre prenom");
        }
        if (e.getSource()==ef.tf_pseudo){
            ef.tf_pseudo.setText("");
            ef.lb_help.setText("help:saisir votre pseudo");
        }
    }

    @Override
    public void focusLost(FocusEvent e) {
        if (e.getSource()==ef.tf_nom && ef.tf_nom.getText().equals("")){
            ef.tf_nom.setText("Tapez votre nom");
            ef.tf_nom.setForeground(Color.GRAY);


        }
        if (e.getSource()==ef.tf_prenom && ef.tf_prenom.getText().equals("")){
            ef.tf_prenom.setText("Tapez votre prenom");
            ef.tf_prenom.setForeground(Color.GRAY);
        }
        if (e.getSource()==ef.tf_pseudo && ef.tf_pseudo.getText().equals("")){
            ef.tf_pseudo.setText("Tapez votre pseudo");
            ef.tf_pseudo.setForeground(Color.GRAY);

    }
    }
}
