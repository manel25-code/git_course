package IHM;

import java.util.ArrayList;

public class Data {
    public static ArrayList<Profil> data= new ArrayList<Profil>();//tableau dynamique
}
