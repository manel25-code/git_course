package IHM;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

public class GestionProfil extends JInternalFrame {
    JPanel pn;
    JLabel lb_nom, lb_prenom, lb_pseudo, lb_help;
    JTextField tf_nom, tf_prenom, tf_pseudo;
    JButton btn_enregistrer;
    JSplitPane jsp;
    JList jl;
    DefaultListModel model;
    JTabbedPane jtp;
    JMenuItem item;
    JMenuItem item1;
    JMenuItem item2;
    Profil p;
    ArrayList<PanelForm> list_Panel = new ArrayList<>();


    public GestionProfil() {
        this.setTitle("Gestion profil");
        this.setSize(400, 400);
        this.setMaximizable(true);
        this.setIconifiable(true);
        this.setLocation(50, 50);
        this.setResizable(true);
        this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        this.setVisible(true);
        this.setLayout(new BorderLayout());
        pn = new JPanel();
        pn.setLayout(new FlowLayout());
        pn.setPreferredSize(new Dimension(500, 200));

        lb_nom = new JLabel("Nom: ");
        lb_prenom = new JLabel("Prenom: ");
        lb_pseudo = new JLabel("Pseudo: ");
        tf_nom = new JTextField(15);
        tf_nom.setText("Tapez le nom");
        tf_prenom = new JTextField(15);
        tf_prenom.setText("Tapez le Prenom");
        tf_pseudo = new JTextField(15);
        tf_pseudo.setText("Tapez le Pseudo");

        btn_enregistrer = new JButton("Enregistrer");
        pn.add(lb_nom);
        pn.add(tf_nom);
        pn.add(lb_prenom);
        pn.add(tf_prenom);
        pn.add(lb_pseudo);
        pn.add(tf_pseudo);
        pn.add(btn_enregistrer);
        this.add(pn, BorderLayout.NORTH);

        lb_help = new JLabel("Help");
        this.add(lb_help, BorderLayout.SOUTH);

        jsp = new JSplitPane();
        model = new DefaultListModel<>();
        jl = new JList<>(model);
        jl.setPreferredSize(new Dimension(150, 50));

        // model.addElement("");
        jsp.setLeftComponent(jl);
        jtp = new JTabbedPane();
        //jtp.addTab("t1",new JPanel());
        // jtp.addTab("T2",new JPanel());
        jsp.setRightComponent(jtp);
        this.add(jsp, BorderLayout.CENTER);
        //evenement
        btn_enregistrer.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String pseudo = tf_pseudo.getText(); // Récupérer le pseudo sans espaces inutiles

                // Vérifier si le pseudo existe déjà avant d'ajouter
                boolean pseudoExiste = false;
                for (Profil profil : Data.data) {
                    if (profil.getPseudo().equalsIgnoreCase(pseudo)) { // Comparaison insensible à la casse
                        pseudoExiste = true;
                        break;
                    }
                }

                if (pseudoExiste) {
                    JOptionPane.showMessageDialog(null, "Erreur : Ce pseudo existe déjà. Veuillez en choisir un autre.");
                } else {
                    // Ajouter le profil si le pseudo est unique
                    Profil nouveauProfil = new Profil(tf_nom.getText(), tf_prenom.getText(), pseudo);
                    Data.data.add(nouveauProfil);
                    model.addElement(pseudo); // Ajout dans le modèle si besoin
                    JOptionPane.showMessageDialog(null, "Enregistrement réussi !");
                }
            }


        });



        lb_nom.addMouseListener(new EcouteursLabel(this));//classe externe don on crre constructeur dans ecouteurslabel
        lb_prenom.addMouseListener(new EcouteursLabel(this));
        lb_pseudo.addMouseListener(new EcouteursLabel(this));
        lb_help.addMouseListener(new EcouteursLabel(this));
        tf_nom.addFocusListener(new EcouteurFocus(this));
        tf_prenom.addFocusListener(new EcouteurFocus(this));
        tf_pseudo.addFocusListener(new EcouteurFocus(this));

       jl.addMouseListener(new MouseAdapter() {
           @Override
           public void mouseClicked(MouseEvent e) {
               super.mouseClicked(e);
               if(e.getClickCount()==2){
                   int index=jl.getSelectedIndex();
                    Profil p=Data.data.get(index);
                   PanelForm pn=new PanelForm(p);
                   list_Panel.add(pn);
                   jtp.addTab(jl.getSelectedValue()+ "",pn);

               }
               if (e.getButton()==MouseEvent.BUTTON3) {
                   //click droite
                   JPopupMenu popup = new JPopupMenu();
                    item = new JMenuItem("Modifier");
                    item1 = new JMenuItem("Supprimer");
                    item2 = new JMenuItem("Supprimer tout");
                   popup.add(item);
                   popup.add(item1);
                   popup.add(item2);
                   popup.show(jl,e.getX(),e.getY());//permet d afficher la liste modif ,.. win eni nzelt
                   item.addActionListener(new EcouteursPopUpMenu(GestionProfil.this));
                   item1.addActionListener(new EcouteursPopUpMenu(GestionProfil.this));
                   item2.addActionListener(new EcouteursPopUpMenu(GestionProfil.this));


               }
           }
       });





    }
}
