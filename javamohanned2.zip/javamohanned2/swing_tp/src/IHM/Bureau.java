package IHM;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Bureau extends JFrame {
    JMenuBar mb;
    JMenu menuTPSwing,menuTPDB;
    JMenuItem mItemTP1,mItemTP2;
    JDesktopPane desktop;

    public Bureau(  ) {
        this.setTitle("TP Java ");
        this.setSize(800, 800);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mb = new JMenuBar();
        this.setJMenuBar(mb);
        menuTPSwing = new JMenu("TP Swing");
        menuTPDB = new JMenu("TP DB");
        mb.add(menuTPSwing);
        mb.add(menuTPDB);
        mItemTP1 = new JMenuItem("TP1");
        mItemTP2 = new JMenuItem("TP2");
        menuTPSwing.add(mItemTP1);
        menuTPSwing.add(mItemTP2);
        desktop = new JDesktopPane();
        this.add(desktop);
        GestionProfil f=new GestionProfil();
        desktop.add(f);
        mItemTP1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Ouvrir le formulaire CurriculumForm lorsque l'utilisateur clique sur TP1
                CurriculumForm curriculumForm = new CurriculumForm();
                curriculumForm.setVisible(true);
            }
        });


        mItemTP2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Ajoute une autre action pour TP2 si nécessaire
                JOptionPane.showMessageDialog(null, "TP2 sélectionné");
            }
        });
    }

    }


