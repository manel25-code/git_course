package DB;

public class Config {
    public static final String nomDriver = "com.mysql.cj.jdbc.Driver";//njibouh m site mtaa base
    public static String url = "jdbc:mysql://localhost:3306/swingDatabase";
    public static String userName = "root";
    public static String password = "root";
}
