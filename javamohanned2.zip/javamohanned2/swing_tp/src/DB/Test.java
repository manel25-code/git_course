package DB;

import java.sql.*;

public class Test {
    public static void main(String[] args) {//on utilise un driver dans intellij pou commeu

        EtudiantManager manager = new EtudiantManager();
        String req="select * from Etudiant";
        ResultSet rs=manager.selectEtudiant(req);
        manager.afficheResultSet(rs);
    }}