package DB;

import java.sql.*;

public class EtudiantManager
{Connection con = null;
    Statement st = null;
    public EtudiantManager(){
        //1-chargement driverpour faire communiquer 2 sys diferents comme java et sql
        try{
            Class.forName(Config.nomDriver);

            System.out.println("Driver charge...");}
        catch(ClassNotFoundException e){
            System.out.println("Erreur chargement driver"+e.getMessage());
        }
        //2-connection a la base lkol

        try {
            con = DriverManager.getConnection(
                    Config.url,
                    Config.userName,
                    Config.password);
            System.out.println("Connected:");
            st = con.createStatement();
        } catch (SQLException e) {
            System.out.println("Erreur connexion"+e.getMessage());
        }


    }
    public int ajouterEtudiant(int cin,String nom,String prenom,double moyenne){
        //3-execution des requetes
        int a=0;
        String requete="insert into etudiant values(?,?,?,?);";
        try {
            PreparedStatement ps = con.prepareStatement(requete);
            ps.setInt(1,cin);
            ps.setString(2,nom);
            ps.setString(3,prenom);
            ps.setDouble(4,moyenne);
            a=ps.executeUpdate();//execute la requete
        } catch (SQLException e) {
            System.out.println("Erreur insertion"+e.getMessage());
        }

        return a;
    }

    public ResultSet selectEtudiant(String requete_selection){
        ResultSet rs=null;//pointeur
        if(st!=null){
            try {
                rs=st.executeQuery(requete_selection);//rs est le resultat de la selection
            } catch (SQLException e) {
                System.out.println("Erreur SELECTION"+e.getMessage());
            }
        }
        return rs;
    }


    public void afficheResultSet(ResultSet rs){
        //requete de selection

        if(rs != null) {
            try {
                //rs est ub pointeur vers les t-uplet
                ResultSetMetaData rsmd = rs.getMetaData();//proection
                //rsmd sont des informations sur la projection ==>champs du selection
                int nbcol= rsmd.getColumnCount();//nb deles colonnes
                for (int i = 1; i <= nbcol; i++) {
                    System.out.print(rsmd.getColumnName(i) + "\t");//pour afficher les entetes cad les noms des champs esm les colonnes
                }
                System.out.println();
                //parcours du resultset
                while (rs.next()) {// parcourir lA LIGNE pointer sur la 1ere ligne //ay 7aja b java sql les indice yabdew bel 1 : parcour ligne par ligne
                    for (int i = 1; i <= nbcol; i++) {
                        System.out.print(rs.getObject(i) + "\t");
                    }
                    System.out.println();

                }
            } catch (SQLException e) {
                System.out.println("Erreur selection"+e.getMessage());
            }
        }}
    public int supprimerEtudiant(int cin) {
        String req = "DELETE FROM etudiant WHERE cin = ?";
        try {
            PreparedStatement ps = con.prepareStatement(req);
            ps.setInt(1, cin);
            return ps.executeUpdate();
        }catch (Exception e) {
            return 0;
        }
    }
   public int modifierEtudiant(int cin, String nouveauNom, String nouveauPrenom, double nouvelleMoyenne) {
        int a = 0;
        String req = "UPDATE etudiant SET nom = ?, prenom = ?, moyenne = ? WHERE cin = ?";
        try {
            PreparedStatement ps = con.prepareStatement(req);
            ps.setString(1, nouveauNom);
            ps.setString(2, nouveauPrenom);
            ps.setDouble(3, nouvelleMoyenne);
            ps.setInt(4, cin);
            a = ps.executeUpdate();
            System.out.println("Modification réussie pour CIN : " + cin);
        } catch (SQLException e) {
            System.out.println("Erreur modification : " + e.getMessage());
        }
        return a;
    }
    }
